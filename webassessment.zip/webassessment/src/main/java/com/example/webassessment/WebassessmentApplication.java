package com.example.webassessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebassessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebassessmentApplication.class, args);
	}

}
