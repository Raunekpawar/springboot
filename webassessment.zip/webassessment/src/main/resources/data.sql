INSERT INTO student (stud_id, name, address, branch) VALUES
(1001, 'Rajesh', 'Trivandrum', 'IT'),
(1002, 'Smitha', 'Chennai', 'Mech'),
(1003, 'Kishore', 'Kochi', 'CS'),
(1004, 'Sandeep', 'Mumbai', 'EE'),
(1005, 'Saranya', 'Trivandrum', 'IT');
